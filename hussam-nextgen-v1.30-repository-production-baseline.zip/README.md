# Hussam NextGen v1.30.0 — Repository & Production Baseline

**Hussam Yemeni Sovereign Platform — NextGen** is a sovereign, modular, multi-tenant operating platform for economic and institutional activity.

## Architecture

`domain → shared engine → Sovereign Core`

Core authorities include identity, tenant/membership context, authorization, policy, audit, events/outbox, idempotency, lifecycle, configuration, and money/data invariants. Shared engines provide finance, inventory, commerce, procurement, payments, logistics, workflow, and documents. Retail and Marketplace are vertical/product layers over those shared authorities.

## Current capabilities

- Multi-tenant identity context and authorization boundary.
- Exact Decimal/Numeric financial values and double-entry finance.
- Inventory, reservations, sales, procurement, payments, logistics, workflow, and business documents.
- Retail vertical.
- Multi-seller marketplace with seller verification, listing moderation, shipping quotes, orders, reviews, disputes, payout controls, and AI read metrics.
- Provider-neutral AI control plane and bounded HUS declarative compiler.
- Arabic RTL operational console.

## v1.30 baseline

This release prepares the repository for the **official independent NextGen GitHub repository**. It adds repository hygiene, environment contract, reproducibility snapshot, CI, baseline static checks, security/contribution policy, architecture baseline, and explicit production gates.

### Verified in the release build

- **129 tests passed**.
- Python compilation passed.
- Fresh Alembic migration through `0015_marketplace_trust_ai_integration` passed on the available SQLite validation path.
- `alembic check` passed.
- Migration chain audit passed.
- Repository secret/runtime artifact audit passed.

### Important: production status

**v1.30 is not a production-readiness declaration.** Real PostgreSQL, production identity, signed payment webhooks, payout rails, browser E2E, backups/restore, observability, deployment/rollback, rate limiting, and legal/compliance gates still require external staging/production evidence.

See:
- `docs/V1_30_REPOSITORY_PRODUCTION_BASELINE.md`
- `docs/ARCHITECTURE_BASELINE_V1_30.md`
- `docs/PRODUCTION_GATES.md`
- `docs/RELEASE_V1_30.md`
- `SECURITY.md`
- `CONTRIBUTING.md`

## Official repository policy

The legacy `hussam-platform-v2` repository remains **reference/legacy**. The new independent `hussam-nextgen` repository becomes the NextGen source of truth after publication.

Do not commit credentials, `.env`, local databases, logs, virtual environments, caches, or generated runtime artifacts.
